import React from 'react';

const Users = () => {
    return (
        <DefaultLayout>
            <div>
                <h1>Users</h1>
            </div>
        </DefaultLayout>
    );
}

export default Users;