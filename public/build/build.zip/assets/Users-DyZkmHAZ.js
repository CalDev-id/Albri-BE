import{j as s}from"./app-Be5eA49W.js";const e=()=>s.jsx(DefaultLayout,{children:s.jsx("div",{children:s.jsx("h1",{children:"Users"})})});export{e as default};
